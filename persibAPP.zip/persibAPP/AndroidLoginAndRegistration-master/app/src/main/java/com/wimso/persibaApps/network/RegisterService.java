package com.wimso.persibaApps.network;

import android.content.Context;

import com.wimso.persibaApps.network.config.RetrofitBuilder;
import com.wimso.persibaApps.network.interfaces.RegisterInterface;

import retrofit2.Callback;

/**
 * Created by Wim on 11/4/16.
 */
public class RegisterService {

    private RegisterInterface registerInterface;

    public RegisterService(Context context) {
        registerInterface = RetrofitBuilder.builder(context)
                .create(RegisterInterface.class);
    }

    public void doRegister(String firstname, String lastname,String username, String email, String password, Callback callback) {
        registerInterface.register(firstname, lastname, username, email, password).enqueue(callback);
    }

}
