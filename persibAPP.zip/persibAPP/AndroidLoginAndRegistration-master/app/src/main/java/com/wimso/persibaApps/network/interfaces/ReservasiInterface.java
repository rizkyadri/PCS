package com.wimso.persibaApps.network.interfaces;

import com.wimso.persibaApps.model.BaseResponse;
import com.wimso.persibaApps.network.config.Config;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ReservasiInterface {
    @FormUrlEncoded
    @POST(Config.API_RESERVASI)
    Call<BaseResponse> reservasi(
            @Field("nama") String nama,
            @Field("no_hp") String no_hp,
            @Field("nopol") String nopol,
            @Field("mobil") String mobil,
            @Field("tanggal") String tvDate,
            @Field("jenis_service") String jenis_service,
            @Field("service_lainnya") String service_lainnya,
            @Field("waktu") String waktu);
}
