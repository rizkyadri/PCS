package com.wimso.persibaApps;


import android.app.Activity;
import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class CustomListView extends ArrayAdapter<String> {

//    private String[] id;
    private String[] nama;
    private String[] mp;
    private String[] w;
    private String[] d;
    private String[] l;
    private String[] pts;

    private Activity context;
    Bitmap bitmap;

    public CustomListView(Activity context,String[] nama,String[] mp,String[] w,String[] d,String[] l,String[] pts) {
        super(context, R.layout.list,nama);
        this.context=context;
//        this.id=id;
        this.nama=nama;
        this.mp=mp;
        this.w=w;
        this.d=d;
        this.l=l;
        this.pts=pts;
    }

    @NonNull
    @Override

    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        View r=convertView;
        ViewHolder viewHolder=null;
        if(r==null){
            LayoutInflater layoutInflater=context.getLayoutInflater();
            r=layoutInflater.inflate(R.layout.list,null,true);
            viewHolder=new ViewHolder(r);
            r.setTag(viewHolder);
        }
        else {
            viewHolder=(ViewHolder)r.getTag();

        }

//        viewHolder.tvw1.setText(id[position]);
        viewHolder.tvw1.setText(nama[position]);
        viewHolder.tvw2.setText(mp[position]);
        viewHolder.tvw3.setText(w[position]);
        viewHolder.tvw4.setText(d[position]);
        viewHolder.tvw5.setText(l[position]);
        viewHolder.tvw6.setText(pts[position]);

        return r;
    }

    class ViewHolder{

        TextView tvw1;
        TextView tvw2;
        TextView tvw3;
        TextView tvw4;
        TextView tvw5;
        TextView tvw6;


        ViewHolder(View v){

            tvw1=(TextView)v.findViewById(R.id.nama);
            tvw2=(TextView)v.findViewById(R.id.mp);
            tvw3=(TextView)v.findViewById(R.id.w);
            tvw4=(TextView)v.findViewById(R.id.d);
            tvw5=(TextView)v.findViewById(R.id.l);
            tvw6=(TextView)v.findViewById(R.id.pts);
        }

    }





}
