package com.wimso.persibaApps.network;


import android.content.Context;

import com.wimso.persibaApps.network.config.RetrofitBuilder;
import com.wimso.persibaApps.network.interfaces.ReservasiInterface;

import retrofit2.Callback;


public class ReservasiSerivice {

    private ReservasiInterface reservasiInterface;

    public ReservasiSerivice(Context context){
        reservasiInterface = RetrofitBuilder.builder(context)
                .create(ReservasiInterface.class);
    }
    public void doReservasi(String nama, String no_hp,String nopol, String mobil,String tanggal, String jenis_service,String service_lainnya,String waktu, Callback callback){
      reservasiInterface.reservasi(nama, no_hp, nopol, mobil, tanggal, jenis_service, service_lainnya, waktu).enqueue(callback);
    }
}
