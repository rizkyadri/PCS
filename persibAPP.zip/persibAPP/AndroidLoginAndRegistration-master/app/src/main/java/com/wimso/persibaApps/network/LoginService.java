package com.wimso.persibaApps.network;

import android.content.Context;

import com.wimso.persibaApps.network.config.RetrofitBuilder;
import com.wimso.persibaApps.network.interfaces.LoginInterface;

import retrofit2.Callback;

/**
 * Created by Wim on 11/4/16.
 */
public class LoginService {

    private LoginInterface loginInterface;

    public LoginService(Context context) {
        loginInterface = RetrofitBuilder.builder(context)
                .create(LoginInterface.class);
    }

    public void doLogin(String username, String password, Callback callback) {
        loginInterface.login(username, password).enqueue(callback);
    }

}
