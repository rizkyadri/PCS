package com.wimso.persibaApps;

import android.content.Context;
import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.wimso.persibaApps.model.User;
import com.wimso.persibaApps.util.PrefUtil;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import okhttp3.Request;
import okhttp3.Response;

public class klasemenActivity extends AppCompatActivity {


    private Toolbar toolbar;
    private TextView username;

//    TextView id;
//    public static final String kata_kunci = "sendata";

    String urladdress="http://persiba.000webhostapp.com/display.php";
//    String[] id;
    String[] nama;
    String[] mp;
    String[] w;
    String[] d;
    String[] l;
    String[] pts;
    ListView listView;
    BufferedInputStream is;
    String line=null;
    String result=null;

    public static void start(Context context) {
        Intent intent = new Intent(context, klasemenActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_klasemen);

//        username = (TextView) findViewById(R.id.username);
//        username.setVisibility(View.INVISIBLE);


//        User user = PrefUtil.getUser(this, PrefUtil.USER_SESSION);
//        username.setText(user.getData().getUsername());


        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        listView=(ListView)findViewById(R.id.lview);

        StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder().permitNetwork().build()));
        collectData();
        CustomListView customListView=new CustomListView(this,nama,mp,w,d,l,pts);
        listView.setAdapter(customListView);

    }

    private void collectData() {
//Connection
        try {

            URL url = new URL(urladdress);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            is = new BufferedInputStream(con.getInputStream());

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        //content
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) {
                sb.append(line + "\n");
            }
            is.close();
            result = sb.toString();

        } catch (Exception ex) {
            ex.printStackTrace();

        }

        //JSON
        try {
            JSONArray ja = new JSONArray(result);
            JSONObject jo = null;
//            id = new String[ja.length()];
            nama = new String[ja.length()];
            mp = new String[ja.length()];
            w = new String[ja.length()];
            d = new String[ja.length()];
            l = new String[ja.length()];
            pts = new String[ja.length()];

            for (int i = 0; i <= ja.length(); i++) {
                jo = ja.getJSONObject(i);
//                id[i] = jo.getString("id");
                nama[i] = jo.getString("nama");
                mp[i] = jo.getString("mp");
                w[i] = jo.getString("w");
                d[i] = jo.getString("d");
                l[i] = jo.getString("i");
                pts[i] = jo.getString("pts");
            }
        } catch (Exception ex) {

            ex.printStackTrace();
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}

