package com.wimso.persibaApps.network.interfaces;

import com.wimso.persibaApps.model.User;
import com.wimso.persibaApps.network.config.Config;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by Wim on 11/3/16.
 */
public interface LoginInterface {

    @FormUrlEncoded
    @POST(Config.API_LOGIN)
    Call<User> login(
            @Field("username") String username,
            @Field("password") String password);

}
