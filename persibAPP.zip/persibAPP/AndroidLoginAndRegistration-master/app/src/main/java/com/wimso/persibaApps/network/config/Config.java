package com.wimso.persibaApps.network.config;

/**
 * Created by Wim on 11/4/16.
 */
public class Config {

    public static final String BASE_URL = "http://192.168.1.67/"; // Your Local IP Address

    public static final String API_URL = BASE_URL + "/persiba";

    public static final String API_LOGIN = API_URL + "/login.php";
    public static final String API_REGISTER = API_URL + "/register.php";
    public static final String API_RESERVASI = API_URL + "/reservasi.php";
    public static final String API_RECORD = API_URL + "/getdata.php";

}