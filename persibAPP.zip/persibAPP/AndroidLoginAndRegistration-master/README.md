# AndroidLoginAndRegistration
Simple Android Login and Registration using PHP &amp; MySQL

![alt tag](https://3.bp.blogspot.com/-selOnvWbZiA/WCQ4_sQ1GPI/AAAAAAAADxM/3q7KIPEQys0_EDTekXtSVXgacCheI-NrgCLcB/s400/device-2016-11-10-145846.png "Registration")
![alt tag](https://2.bp.blogspot.com/-Ie94irOVPlg/WCQ5KfPCDJI/AAAAAAAADxQ/e2i2RghqMTgBGrdvi2zHZFxOhR_LLGbZwCLcB/s400/device-2016-11-10-145924.png "Login")
![alt tag](https://4.bp.blogspot.com/-WVsvUkIwRDc/WCQ5UqGyU_I/AAAAAAAADxU/9GDZFAMO0Qgtx4VE1NHrQRSCZ0j5rVeNACLcB/s400/device-2016-11-10-145940.png "Dashboard")
